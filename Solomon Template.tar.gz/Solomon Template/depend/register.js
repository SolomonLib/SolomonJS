$.register.components([

]);

$.register.pages([

]);

$.register.scripts([

]);




//// EXAMPLE ////
// components([
//     'header' - This will take a file named header.js in the app/component folder. the header.js file would have a function called header()
// ]);

// pages([
//     'home' - This will take a file named home.js from app/page. The home.js file will have a function named home().
// ]);

// scripts([
//     'foobar' - This will take a file named foobar.js from the app folder. This file can have any number of functions inside.
// ]);